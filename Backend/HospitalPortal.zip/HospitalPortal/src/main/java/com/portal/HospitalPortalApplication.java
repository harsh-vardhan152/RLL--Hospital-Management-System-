package com.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalPortalApplication.class, args);
	}

}
